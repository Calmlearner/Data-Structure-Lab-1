//#include <iostream>
//using namespace std;
//
//class Shape
//{
//public:
//
//    virtual float Area() = 0;
//};
//
//class Circle : public Shape
//{
//private:
//    float radius;
//
//public:
//    Circle(float r)
//    {
//        radius = r;
//    }
//
//    float Area()
//    {
//        return 3.14 * radius * radius;
//    }
//};
//
//
//class Rectangle : public Shape
//{
//private:
//    float length;
//    float width;
//
//public:
//    Rectangle(float l, float w)
//    {
//        length = l;
//        width = w;
//    }
//
//    float Area()
//    {
//        return length * width;
//    }
//};
//
//
//int main()
//{
//    Circle c(5);
//    Rectangle r(4, 6);
//
//    cout << "Area of Circle: " << c.Area() << endl;
//    cout << "Area of Rectangle: " << r.Area() << endl;
//
//    return 0;
//}