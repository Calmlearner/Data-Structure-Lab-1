#include <iostream>
#include <string>
using namespace std;

// Template function for Linear Search
template <typename T>
int linearSearch(T arr[], T key, int size)
{
    for (int i = 0; i < size; i++)
    {
        if (arr[i] == key) 
        {
            return i;   // Found
        }
    }
    return -1;  // Not found
}


template <typename T>
void printSearchResult(int index, T key) 
{
    if (index != -1)
        cout << "Element \"" << key << "\" Found At Index= " << index << endl;
    else
        cout << "Element \"" << key << "\" Not Found In The Array= " << endl;
}

int main() 
{

    int size;

    // ===== Integer Array =====
    cout << "Enter Size Of An Integer Array=  ";
    cin >> size;
    int* intArray = new int[size];
    cout << "Enter " << size << " Integers= ";
    for (int i = 0; i < size; i++)
    {
        cin >> intArray[i];
    }

    int intKey;
    cout << "Enter Integer Value To Search=  ";
    cin >> intKey;

    int intIndex = linearSearch(intArray, intKey, size);
    printSearchResult(intIndex, intKey);

    delete[] intArray;


    // ===== Float Array =====
    cout << "\nEnter Size Of Float Array: ";
    cin >> size;

    float* floatArray = new float[size];

    cout << "Enter " << size << " Float Values= ";
    for (int i = 0; i < size; i++) 
    {
        cin >> floatArray[i];
    }

    // ===== Float Array ===== 

    float floatKey;
    cout << "Enter Float Value To Search= ";
    cin >> floatKey;
    int floatIndex = linearSearch(floatArray, floatKey, size);
    printSearchResult(floatIndex, floatKey);

    delete[] floatArray;


    // ===== String Array =====
    cout << "\nEnter Size Of String Array: ";
    cin >> size;
    string* stringArray = new string[size];
    cout << "Enter " << size << " Strings= ";
    for (int i = 0; i < size; i++)
    {

        cin >> stringArray[i];
     
    }

    string stringKey;
    cout << "Enter String Value To Search=  ";
    cin >> stringKey;
    int stringIndex = linearSearch(stringArray, stringKey, size);
    printSearchResult(stringIndex, stringKey);

    delete[] stringArray;

    return 0;
}