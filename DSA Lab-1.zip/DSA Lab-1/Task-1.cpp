//#include <iostream>
//#include <string>
//using namespace std;
//
//
//template <typename T>
//void printArray(T arr[], int size) 
//{
//    for (int i = 0; i < size; i++) 
//    {
//        cout << arr[i] << " ";
//    }
//    cout << endl;
//}
//
//
//template <typename T>
//void selectionSort(T arr[], int size) 
//{
//    for (int i = 0; i < size - 1; i++)
//    {
//        int minIndex = i;
//
//        for (int j = i + 1; j < size; j++)
//        {
//            if (arr[j] < arr[minIndex])
//            {
//                minIndex = j;
//            }
//        }
//
//        
//        if (minIndex != i) 
//        {
//            swap(arr[i], arr[minIndex]);
//        }
//    }
//}
//
//int main() 
//{
//
//  //Test with Integer array
//
//    int intArray[5] = { 65,54,34,64,23 };
//    cout << "Original Integer Array=  ";
//    printArray(intArray, 5);
//    selectionSort(intArray, 5);
//    cout << "Sorted Inetegr Array =  ";
//    printArray(intArray, 5);
//
//    //Test With String array
//
//    string stringArray[4] = { "Papaya", "Dates", "Guava", "Plums" };
//    cout << "\nOriginal String Array=  ";
//    printArray(stringArray, 4);
//    selectionSort(stringArray, 4);
//    cout << "Sorted String array=  ";
//    printArray(stringArray, 4);
//
//    return 0;
//}